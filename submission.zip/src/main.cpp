#include <tsh.h>

/**
 * @brief the main runner, nothing to do here.
 *
 * @return int
 */
int main() {
  run();
  exit(0);
}
